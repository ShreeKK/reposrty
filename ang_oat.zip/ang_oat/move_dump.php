<?php
$eid = $_GET['mvdmp'];

include_once 'dbConnection.php';


	//For Fetching Questions from Question table to user_answer table
	$q1 = mysqli_query($con, "UPDATE `user_answer` t2 INNER JOIN questions t1 ON t2.qid = t1.qid AND t2.eid = t1.eid SET t2.question = t1.qns ") or die('Error197');

	//For Fetching Selected Answer from Options table to user_answer table
	$q2 = mysqli_query($con, "UPDATE `user_answer` t2 INNER JOIN options t1 ON t2.ans = t1.optionid AND t2.qid = t1.qid SET t2.sel_ans = t1.option ") or die('Error197');

	//For Fetching Correct Answer from Options table to user_answer table
	$q3 = mysqli_query($con, "UPDATE `user_answer` t2 INNER JOIN options t1 ON t2.correctans = t1.optionid AND t2.qid = t1.qid SET t2.correct_ans = t1.option ") or die('Error197');

header("location:dash.php?q=7") or die('Error152');

?>