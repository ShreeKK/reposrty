<?php
	include('conn.php');
 
	$empid=$_POST['empid']
	$username=$_POST['username'];
	$emp_name=$_POST['emp_name'];
	$emp_role=$_POST['emp_role'];
 
	mysqli_query($conn,"insert into `auditor_info` (empid, username, emp_name, emp_role) values ('$empid', '$username', '$emp_name', '$emp_role')");
	header('location:/my_audit/admin/edit_record/index.php');
 
?>