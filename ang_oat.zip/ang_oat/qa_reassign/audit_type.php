<?php
// Initialize the session
session_start();
date_default_timezone_set("Asia/Kolkata");
$username = get_current_user();
?>
<?php
        include('conn.php');
        $id=$_GET['title'];
?>
<!DOCTYPE html>
<html>
<head>
<title>Super QA Reassign | A&G Smart Audit</title>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>  
           <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  
           <script src="http://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>  
           <link rel="stylesheet" href="http://code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css"> 
           <style type="text/css">
            body
            { 
                font: 15px sans-serif; text-align: center; background: #AFEEEE; 
            }
        </style> 
</head>
<body>
	<div>

		<!--<div class="container" style="width:900px;">  -->
                <h2 align="center">Hello, <b><?php echo htmlspecialchars($_SESSION['username']); ?>.</b> Welcome to Audit Reassign Panel.</h2>  
                <h3 align="center">Pending Audit Data</h3><br />
         </div>  
			
		<a href="/ang_audit/admin/qa_reassign/index.php" button type="submit" class="btn btn-danger">Back to Menu</a></br></br>
	<br>
	<div>
		<table border="1" align="center">
			<thead>
				<th align="center">&nbsp; Sr. No. &nbsp;</th>
				<th align="center">&nbsp; Audit Type &nbsp;</th>
				<th align="center">&nbsp; Completed Cases &nbsp;</th>
				<th align="center">&nbsp; Pending Cases &nbsp;</th>
				<th align="center">&nbsp; Total &nbsp;</th>
				<th align="center">&emsp; Action &nbsp;</th>
				<th></th>
			</thead>
			<tbody>
				<?php
					include('conn.php');
					$query=mysqli_query($conn,"SELECT DISTINCT processor_name FROM `processor_data`");
					//$row=mysqli_fetch_array($query);
					$counter = 0;
					while ($row=mysqli_fetch_array($query))
					{
						?>
						<tr>
							<td> &nbsp <?php echo ++$counter;  ?> &nbsp </td>
							<td> &nbsp <?php echo $row['processor_name']; ?> &nbsp </td>
							<?php
								$query2 = mysqli_query($conn,"SELECT count(*) as count2 FROM `ang_data_temp` where audit_status = '' AND qa_msid= '$id' AND audit_type = '".$row['audit_type']."'");
								$row2 = mysqli_fetch_assoc($query2);

								$query3 = mysqli_query($conn,"SELECT count(*) as count3 FROM `ang_data_temp` where audit_status <> '' AND qa_msid= '$id' AND audit_type = '".$row['audit_type']."'");
								$row3 = mysqli_fetch_assoc($query3);

								$query4 = mysqli_query($conn,"SELECT count(*) as count4 FROM `ang_data_temp` where qa_msid= '$id' AND audit_type = '".$row['audit_type']."'");
								$row4 = mysqli_fetch_assoc($query4);
							?>
							<td> &nbsp <?php echo $row3['count3']; ?> &nbsp </td>
							<td> &nbsp <?php echo $row2['count2']; ?> &nbsp </td>
							<td> &nbsp <?php echo $row4['count4']; ?> &nbsp </td>
							<td>
								<a href="/ang_audit/admin/qa_reassign/edit.php?audit_type=<?php echo $row['audit_type']; ?>&aid=<?php echo $id ?>">&nbsp Reassign &nbsp</a>
							</td>
						</td>
					</tr>
						<?php
					}
					?>
			</tbody>
		</table>
	</div>
</body>
</html>
