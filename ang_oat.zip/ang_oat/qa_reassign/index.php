<?php
// Initialize the session
session_start();
ini_set('max_execution_time', 300);
date_default_timezone_set("Asia/Kolkata");
?>
<?php
    $tday = date("Y-m-d");
    //$count2 = "4"
//    @$assign_count = $_POST["ass_val"];
//    @$super_title = $_POST["emp_list"];
//    $sup_name = $_SESSION['username'];

        include('conn.php');
?>
<!DOCTYPE html>
<html>
<head>
<title>Super QA Reassign | A&G Smart Audit</title>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>  
           <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  
           <script src="http://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>  
           <link rel="stylesheet" href="http://code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css"> 
           <style type="text/css">
            body
            { 
                font: 15px sans-serif; text-align: center; background: #AFEEEE; 
            }
        </style> 
</head>
<body>
	<div>

		<!--<div class="container" style="width:900px;">  -->
                <h2 align="center">Hello, <b><?php echo htmlspecialchars($_SESSION['username']); ?>.</b> Welcome to Audit Reassign Panel.</h2>  
                <h3 align="center">Pending Audit Data</h3><br />
         </div>  
			
		<a href="/ang_audit/admin/Audittool/admin.php" button type="submit" class="btn btn-danger">Back to Menu</a></br></br>		
		<!--<a href="/ang_audit/admin/qa_reassign_night/index.php" button type="submit" class="btn btn-warning">Go to Night-Shift</a></br></br> -->
		
	<br>
	<div>
		<table border="1" align="center">
			<thead>
				<th align="center">&nbsp; Sr. No. &nbsp;</th>
				<th align="center">&nbsp; Quiz Name &nbsp;</th>
				<th align="center">&nbsp; Quiz UID &nbsp;</th>
				<th align="center">&nbsp; Action &nbsp;</th>
				<th></th>
				
			</thead>
			<tbody>
				<?php
					
					$query=mysqli_query($conn,"SELECT DISTINCT title, eid FROM `quiz`");
					//$row=mysqli_fetch_array($query);
					$counter = 0;
					while ($row=mysqli_fetch_array($query))
					{
						?>
						<tr>
							<td> &nbsp <?php echo ++$counter;  ?> &nbsp </td>
							<td> &nbsp <?php echo $row['title']; ?> &nbsp </td>
							<td> &nbsp <?php echo $row['eid']; ?> &nbsp </td>
							<td>
								<a href="/ang_oat/qa_reassign/edit.php?title=<?php echo $row['eid']; ?>">&nbsp Reassign &nbsp</a>				
							</td>
						</td>
					</tr>
						<?php
					}
					?>
			</tbody>
		</table>
	</div>
</body>
</html>
