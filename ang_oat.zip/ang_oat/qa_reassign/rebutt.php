<?php
// Initialize the session
session_start();
ini_set('max_execution_time', 300);
date_default_timezone_set("Asia/Kolkata");
$username = get_current_user();
// If session variable is not set it will redirect to login page
if(!isset($_SESSION['username']) || empty($_SESSION['username'])){
    header("location: /ang_audit/login.php");
    exit;
}
?>
<?php
    $tday = date("Y-m-d");
    //$count2 = "4"
//    @$assign_count = $_POST["ass_val"];
//    @$super_qa_msid = $_POST["emp_list"];
//    $sup_name = $_SESSION['username'];

        include('conn.php');
?>
<!DOCTYPE html>
<html>
<head>
<title>Rebutted Cases Report | A&G Smart Audit</title>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>  
           <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  
           <script src="http://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>  
           <link rel="stylesheet" href="http://code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css"> 
           <style type="text/css">
            body
            { 
                font: 15px sans-serif; text-align: center; background: #AFEEEE; 
            }
            th 
            {
  				text-align: center;
			}
        </style> 
</head>
<body>
	<div>

		<!--<div class="container" style="width:900px;">  -->
                <h2 align="center">Hello, <b><?php echo htmlspecialchars($_SESSION['username']); ?>.</b> Welcome to Audit Rebutted Cases Report Panel.</h2>  
                <h3 align="center">Rebutted Data</h3><br />
         </div>  
			
		<a href="/ang_audit/admin/Audittool/admin.php" button type="submit" class="btn btn-danger">Back to Menu</a></br></br>
	
		
	<br>
	<div>
		<table border="1" align="center">
			<thead>
				<th align="center">No.</th>
				<th align="center">QA Name</th>
				<th align="center">Total Audit</th>
				<th align="center">Defect Cases</th>
				<th align="center">Error Accepted</th>
				<th align="center">Error Review Pending</th>
				<th align="center">Rebuttal Pending</th>
				<th align="center">Error Upheld</th>
				<th align="center">Error Overturn</th>
				<th align="center">Pending Super Audit</th>
				<th align="center">Complete Super Audit</th>
				<th></th>
			</thead>
			<tbody>
				<?php
					include('conn.php');
					$query=mysqli_query($conn,"SELECT DISTINCT qa_msid FROM `ang_data`");
					//$row=mysqli_fetch_array($query);
					$counter = 0;
					while ($row=mysqli_fetch_array($query))
					{
						?>
						<tr>
							<td> &nbsp <?php echo ++$counter;  ?> &nbsp </td>
							<td> &nbsp <?php echo $row['qa_msid']; ?> &nbsp </td>

							<?php
								$msid=$row['qa_msid'];
								$query2 = mysqli_query($conn,"SELECT count(*) as count2 FROM `ang_data` where audit_status <> '' AND qa_msid= '$msid'");
								$row2 = mysqli_fetch_assoc($query2);

								$query3 = mysqli_query($conn,"SELECT count(*) as count3 FROM `ang_data` where audit_status = 'INCORRECT' AND qa_msid= '$msid'");
								$row3 = mysqli_fetch_assoc($query3);

								$query4 = mysqli_query($conn,"SELECT count(*) as count4 FROM `ang_data` where qa_msid = '$msid' AND processor_status = 'Error Accepted'");
								$row4 = mysqli_fetch_assoc($query4);

								$query5 = mysqli_query($conn,"SELECT count(*) as count5 FROM `ang_data` where qa_msid = '$msid' AND processor_status = '' AND audit_status = 'INCORRECT'");
								$row5 = mysqli_fetch_assoc($query5);

								$query6 = mysqli_query($conn,"SELECT count(*) as count6 FROM `ang_data` where qa_msid = '$msid' AND processor_status = 'Rebuttal Raised'");
								$row6 = mysqli_fetch_assoc($query6);

								$query7 = mysqli_query($conn,"SELECT count(*) as count7 FROM `ang_data` where qa_msid = '$msid' AND qa_rebutaal_status = 'Error Appeal'");
								$row7 = mysqli_fetch_assoc($query7);

								$query8 = mysqli_query($conn,"SELECT count(*) as count8 FROM `ang_data` where qa_msid = '$msid' AND qa_rebutaal_status = 'Error Overturn'");
								$row8 = mysqli_fetch_assoc($query8);

								$query9 = mysqli_query($conn,"SELECT count(*) as count9 FROM `ang_data` where qa_msid = '$msid' AND super_qa_status = '' AND super_qa = '' AND processor_status = 'Re Rebuttal Raised' ");
								$row9 = mysqli_fetch_assoc($query9);

								$query10 = mysqli_query($conn,"SELECT count(*) as count10 FROM `ang_data` where qa_msid = '$msid' AND super_qa_status <> ''");
								$row10 = mysqli_fetch_assoc($query10);
							?>
							<td> &nbsp <?php echo $row2['count2']; ?> &nbsp </td>
							<td> &nbsp <?php echo $row3['count3']; ?> &nbsp </td>
							<td> &nbsp <?php echo $row4['count4']; ?> &nbsp </td>
							<td> &nbsp <?php echo $row5['count5']; ?> &nbsp </td>
							<td> &nbsp <?php echo $row6['count6']; ?> &nbsp </td>
							<td> &nbsp <?php echo $row7['count7']; ?> &nbsp </td>
							<td> &nbsp <?php echo $row8['count8']; ?> &nbsp </td>
							<td> &nbsp <?php echo $row9['count9']; ?> &nbsp </td>
							<td> &nbsp <?php echo $row10['count10']; ?> &nbsp </td>
						</td>
					</tr>
						<?php
					}
					?>
			</tbody>
		</table>
	</div>
</body>
</html>
