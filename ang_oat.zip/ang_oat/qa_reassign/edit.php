<?php
	include('conn.php');
	$id=$_GET['title'];
?>
<!DOCTYPE html>
<html>
<head>
<title>Update QA | A&G Smart Audit</title>
<style type="text/css">
            body
            { 
                font: 15px sans-serif; text-align: center; background: #AFEEEE; 
            }
        </style> 
</head>
<body align="center">
	<h2>Update QA</h2>
    </b> &nbsp <br>
	<form method="POST" action="/ang_oat/qa_reassign/update.php?aid=<?php echo $id ?>"></br></br>
		<label>Quiz Name:</label></br>
		<input type="text" value="<?php echo $id; ?>" name="qa_name" readonly></br></br>
		<label>Name</label></br>
		<select id="qa_list" name="qa_list">
        <?php
        $query = "SELECT `processor_name` FROM `processor_data`";
        $result = mysqli_query($conn, $query);
        if(mysqli_num_rows($result) > 0)  
        {  
           while($row = mysqli_fetch_array($result))  
           {  
                echo "<option>";
                echo $row["processor_name"];
                echo "</option>"; 
           }  
        }  
        else  
        {  
           echo "<option>";
           echo "No User Found";
           echo "</option>";
        }
        ?>
    </select></br></br>
		<input type="submit" name="submit">
		<a href="/ang_oat/qa_reassign/index.php">Back</a>
	</form>
</body>
</html>