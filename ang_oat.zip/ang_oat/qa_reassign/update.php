<?php
	include('conn.php');
	$id = $_GET['aid'];
	$new_qa = $_POST['qa_list'];

	echo "$id";
	echo "$new_qa";

	$query2 = mysqli_query($conn,"SELECT * FROM `processor_data` where processor_name = $new_qa");
	$row2 = mysqli_fetch_assoc($query2);
	echo $row2['msid'];
	mysqli_query($conn,"DELETE FROM `history` WHERE eid =$id AND username = '".$row2['count2']."'");
	mysqli_query($conn,"DELETE FROM `user_answer` WHERE eid =$id AND username = '".$row2['count2']."'");

	//header('location:/ang_oat/qa_reassign/index.php');
?>