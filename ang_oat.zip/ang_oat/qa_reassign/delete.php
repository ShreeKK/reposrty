<?php
	$id=$_GET['id'];
	include('conn.php');
	mysqli_query($conn,"delete from `auditor_login` where id='$id'");
	header('location:/ang_audit/admin/edit_auditor/index.php');
?>