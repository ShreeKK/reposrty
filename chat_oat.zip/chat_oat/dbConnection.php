<?php
	$con= new mysqli('localhost','root','','chat_oat')or die("Could not connect to mysql".mysqli_error($con));
?>