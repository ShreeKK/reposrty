<?php  
//export.php  

$eid = $_GET['dnrep'];
include_once 'dbConnection.php';
$output = '';
$counter = 0;
 $query = "SELECT * FROM history where eid = '$eid' order by score desc ";
 $result = mysqli_query($con, $query);
 if(mysqli_num_rows($result) > 0)
 {
  $output .= '
   <table class="table" bordered="1">  
                    <tr>  
                         <th>Sr. No</th> 	
                         <th>Exam Date</th> 
                         <th>Username</th>
                         <th>Final Score</th>
                         <th>Correct Answers</th>
                         <th>Wrong Answers</th>
                         <th>Submitted at</th> 
                         <th>Status</th>          
                    </tr>
  ';
  while($row = mysqli_fetch_array($result))
  {
   $output .= '
    <tr>  
      <td>'.++$counter.'</td>  
      <td>'.$row["exam_date"].'</td>  
      <td>'.$row["username"].'</td>  
      <td>'.$row["score"].'</td>  
      <td>'.$row["correct"].'</td>
      <td>'.$row["wrong"].'</td>
      <td>'.$row["date"].'</td>
      <td>'.$row["status"].'</td>
   </tr>
   ';
  }
  $output .= '</table>';
  $filename = "Test_Report_".date('y-m-d') . ".xls";
  header('Content-Type: application/xlsx');
  header("Content-Disposition: attachment; filename=\"$filename\"");
  echo $output;
 }
?>