<?php  
//export.php  

$eid = $_GET['dndmp'];
include_once 'dbConnection.php';
$output = '';
$counter = 0;
 $query = "SELECT * FROM user_answer where eid = '$eid' order by username desc ";
 $result = mysqli_query($con, $query);
 if(mysqli_num_rows($result) > 0)
 {
  $output .= '
   <table class="table" bordered="1">  
                    <tr>  
                         <th>Sr. No</th> 	
                         <th>Username</th>                  
                         <th>Question</th>
                         <th>Selected Answer</th>
                         <th>Correct Answer</th>                         
                    </tr>
  ';
  while($row = mysqli_fetch_array($result))
  {
   $output .= '
    <tr>  
      <td>'.++$counter.'</td>      
      <td>'.$row["username"].'</td>    
      <td>'.$row["question"].'</td>  
      <td>'.$row["sel_ans"].'</td>  
      <td>'.$row["correct_ans"].'</td>        
   </tr>
   ';
  }
  $output .= '</table>';
  $filename = "Test_Dump_Report_".date('y-m-d') . ".xls";
  header('Content-Type: application/xlsx');
  header("Content-Disposition: attachment; filename=\"$filename\"");
  echo $output;
 }
?>