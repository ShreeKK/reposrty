<?
		include_once 'dbConnection.php';
		$dusername = @$_POST['dusername'];
        $result = mysqli_query($con, "UPDATE processor_data SET audit_status = 'shrikant'") or die('Error');
        if ($result){
        	return "success!";
        //mysqli_close($con);
        }
        else{
        	return "Fail!";
        }
?>