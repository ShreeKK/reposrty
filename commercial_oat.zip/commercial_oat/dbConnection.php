<?php
	$con= new mysqli('localhost','root','','commercial_oat')or die("Could not connect to mysql".mysqli_error($con));
?>